document.addEventListener('DOMContentLoaded', () => {
  const saveBtn = document.getElementById('saveConfig');
  const statusDiv = document.getElementById('status');
  const inputs = {
    deepseekKey: document.getElementById('deepseekKey'),
    notionToken: document.getElementById('notionToken'),
    notionDbId: document.getElementById('notionDbId')
  };

  // 加载已保存的配置
  chrome.storage.sync.get(['deepseekKey', 'notionToken', 'notionDbId'], (config) => {
    inputs.deepseekKey.value = config.deepseekKey || '';
    inputs.notionToken.value = config.notionToken || '';
    inputs.notionDbId.value = config.notionDbId || '';
  });

  saveBtn.addEventListener('click', async () => {
    const config = {
      deepseekKey: inputs.deepseekKey.value.trim(),
      notionToken: inputs.notionToken.value.trim(),
      notionDbId: inputs.notionDbId.value.trim()
    };

    // 验证配置
    if (!config.deepseekKey) {
      showStatus('DeepSeek API密钥不能为空', 'error');
      return;
    }
    if (!config.notionToken || !config.notionDbId) {
      showStatus('Notion配置信息不完整', 'error');
      return;
    }

    try {
      await chrome.storage.sync.set(config);
      showStatus('配置保存成功', 'success');
      setTimeout(() => window.close(), 1000);
    } catch (error) {
      showStatus(`保存失败: ${error.message}`, 'error');
    }
  });

  function showStatus(message, type = 'info') {
    statusDiv.style.display = 'block';
    statusDiv.textContent = message;
    statusDiv.className = '';
    statusDiv.classList.add(type);
    
    setTimeout(() => {
      statusDiv.style.display = 'none';
    }, 3000);
  }
});
