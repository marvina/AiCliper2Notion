// 提取页面核心内容（调试版本）
// 在文件顶部添加版本标识（用于验证脚本加载）
console.log('[内容脚本v1.2] 已加载');

// 在extractContent函数开头添加调试标记
function extractContent() {
  console.log('[内容脚本] 开始执行提取流程');
  console.debug('当前域名:', window.location.hostname);
  const title = document.title;
  const url = window.location.href;
  
  // 优先选择的CSS选择器列表
  const contentSelectors = [
    'article',
    '[itemprop="articleBody"]',
    '.post-content',
    '.article-content',
    '.content',
    '.main-content',
    '#content',
    '#article',
    '.entry-content',
    'main'
  ];

  // 按优先级查找内容区域
  // 增加容错处理（插入在mainContent定义后）
  const mainContent = document.querySelector('article') || 
    document.querySelector('[itemprop="articleBody"]') ||
    document.querySelector('.post-content, .article-content, .content') ||
    document.body;

  // 新增内容清洗逻辑（插入在返回对象前）
  return {
    title: title.trim().replace(/\s+/g, ' '),
    content: mainContent.innerText
      .replace(/[\n]{3,}/g, '\n\n')  // 清理多余空行
      .substring(0, 10000),         // 增加内容长度限制
    image: mainImage,
    url: url.split('?')[0] // 去除URL参数
  };

  try {
    return {
      title,
      content: mainContent?.innerText || '',
      image: mainImage || '',
      url
    };
  } catch (error) {
    console.error('内容提取失败:', error);
    return {
      title,
      content: '',
      image: '',
      url
    };
  }
}

// 监听来自background的消息（带超时处理）
// 在消息监听器中添加错误处理
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getPageContent') {
    try {
      sendResponse(extractContent());
    } catch (error) {
      console.error('内容提取失败:', error);
      sendResponse({ error: error.message });
    }
  }
  return true;
});
