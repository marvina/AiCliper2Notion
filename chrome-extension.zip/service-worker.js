let config = {};
const MAX_LOG_ENTRIES = 100;
let logs = [];

// 初始化配置
chrome.storage.sync.get(['deepseekKey', 'notionToken', 'notionDbId'], (result) => {
  config = result;
});

// 监听配置变化
chrome.storage.onChanged.addListener((changes) => {
  if (changes.deepseekKey) config.deepseekKey = changes.deepseekKey.newValue;
  if (changes.notionToken) config.notionToken = changes.notionToken.newValue;
  if (changes.notionDbId) config.notionDbId = changes.notionDbId.newValue;
});

// 日志系统
function addLog(message, level = 'info') {
  logs.push({
    timestamp: Date.now(),
    level,
    message: typeof message === 'string' ? message : JSON.stringify(message)
  });
  if (logs.length > MAX_LOG_ENTRIES) logs.shift();
  chrome.runtime.sendMessage({
    action: 'newLog',
    text: message,
    timestamp: Date.now(),
    level
  }).catch(() => {});
}

// 消息处理
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'processAndSave') {
    handleSaveRequest(request.tabId, sendResponse);
    return true;
  }
  if (request.action === 'getLogs') {
    sendResponse(logs);
  }
});

async function handleSaveRequest(tabId, sendResponse) {
  try {
    addLog('开始处理保存请求');
    
    // 检查配置
    if (!config.deepseekKey || !config.notionToken || !config.notionDbId) {
      throw new Error('请先完成API配置');
    }

    // 获取页面内容
    const pageData = await getPageContent(tabId);
    addLog('页面内容获取结果', pageData);
    
    if (!pageData?.content) {
      throw new Error('无法提取页面内容');
    }

    // 内容处理
    addLog('开始内容摘要处理');
    const processedContent = await processContent(pageData.content);
    
    // 构建Notion数据
    const notionData = {
      parent: { database_id: config.notionDbId },
      properties: {
        '标题': { title: [{ text: { content: pageData.title || '无标题' } }] },
        '网址': { url: pageData.url },
        '摘要': { rich_text: [{ text: { content: processedContent.summary } }] },
        '大纲': { rich_text: [{ text: { content: processedContent.outline } }] },
        '日期': { date: { start: new Date().toISOString() } },
        '封面': { files: [{ name: 'cover', external: { url: pageData.image || '' } }] }
      }
    };

    // 保存到Notion
    addLog('正在保存到Notion...');
    await saveToNotion(notionData);
    
    sendResponse({ success: true });
    addLog('保存成功');
  } catch (error) {
    addLog(`保存失败: ${error.message}`, 'error');
    sendResponse({ success: false, error: error.message });
  }
}

async function getPageContent(tabId) {
  try {
    const [results] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        return new Promise(resolve => {
          chrome.runtime.sendMessage(
            { action: 'getPageContent' },
            (response) => resolve(response || {})
          );
        });
      }
    });
    return results?.result || {};
  } catch (error) {
    addLog(`内容脚本执行失败: ${error.message}`, 'error');
    return {};
  }
}

async function processContent(content) {
  try {
    const response = await fetch('https://api.deepseek.com/v1/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.deepseekKey}`
      },
      body: JSON.stringify({
        model: "deepseek-chat",
        messages: [{
          role: "user",
          content: `请将以下内容整理为包含摘要和大纲的JSON格式：
{
  "summary": "内容摘要（200字内，中文）",
  "outline": ["大纲条目1", "大纲条目2", "..."]
}

原始内容：
${content.substring(0, 3000)}`
        }]
      })
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(`DeepSeek API错误: ${err?.message || response.status}`);
    }

    const data = await response.json();
    const resultText = data.choices[0]?.message?.content || '';
    
    try {
      const result = JSON.parse(resultText);
      return {
        summary: result.summary || '无摘要',
        outline: result.outline?.join('\n') || '无大纲'
      };
    } catch {
      return { summary: resultText, outline: '自动生成大纲失败' };
    }
  } catch (error) {
    addLog(`内容处理失败: ${error.message}`, 'error');
    throw error;
  }
}

async function saveToNotion(data) {
  try {
    const response = await fetch('https://api.notion.com/v1/pages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.notionToken}`,
        'Notion-Version': '2022-06-28'
      },
      body: JSON.stringify(data)
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`Notion保存失败: ${error.message || response.status}`);
    }
    return response.json();
  } catch (error) {
    addLog(`Notion API错误: ${error.message}`, 'error');
    throw error;
  }
}
