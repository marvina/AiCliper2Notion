// 提取页面核心内容（调试版本）
function extractContent() {
  console.log('内容脚本开始执行');
  const title = document.title;
  const url = window.location.href;
  
  // 改进的内容提取算法
  const mainContent = document.querySelector('article') || 
    document.querySelector('[itemprop="articleBody"]') ||
    document.querySelector('.post-content, .article-content, .content') ||
    document.body;

  // 提取图片（优先选择og:image或最大的图片）
  const ogImage = document.querySelector('meta[property="og:image"]')?.content;
  const images = Array.from(document.images);
  const mainImage = ogImage || images.reduce((a, b) => 
    (a.naturalWidth * a.naturalHeight) > (b.naturalWidth * b.naturalHeight) ? a : b
  )?.src;

  try {
    return {
      title,
      content: mainContent?.innerText || '',
      image: mainImage || '',
      url
    };
  } catch (error) {
    console.error('内容提取失败:', error);
    return {
      title,
      content: '',
      image: '',
      url
    };
  }
}

// 监听来自background的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getPageContent') {
    sendResponse(extractContent());
  }
  return true;
});
